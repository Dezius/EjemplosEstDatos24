#include <iostream>

int main(int argc, char **argv)
{
	int x;
    std::cout << "Escribe un numero: ";
    std::cin >> x;
    std::cout << "El numero introducido es: " << x << "\n";
    
	return 0;
}
