#include "Persona.hpp"

using namespace std;

Persona::Persona(int edad){
	this->edad = edad;
	this->genero = (rand() % 2);
	this->dni = "xxxxxxxxxx";
}
    
int Persona::getEdad(){
	return this->edad;
}

bool Persona::esMujer(){
	return this->genero;
}

void Persona::setEdad(int edad){
	this->edad = edad;
}

void Persona::mostrar(){
	string sexo = "El hombre ";
	if(genero)
		sexo = "La mujer ";
	cout << sexo + "tiene " << edad << "anyos y su DNI es " << dni << "." << endl; 
}

Persona::~Persona(){ 
}