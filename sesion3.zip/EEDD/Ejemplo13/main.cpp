#include <stdio.h>
#include <Persona.hpp>
using namespace std;

int main(int argc, char **argv)
{
    int edad = 18;
	for(int i=0; i<9; i++){
        Persona* p = new Persona(edad);
        edad++;
        p.mostrar();
    }
}
